<div wire:loading.delay>
    <div class="spinner-mid">
        <div class="la-ball-spin la-3x">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>