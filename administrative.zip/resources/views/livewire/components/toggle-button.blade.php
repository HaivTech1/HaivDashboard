<div class="form-check form-switch">
    <input class="form-check-input" wire:model="isAvailable" type="checkbox" role="switch"
        @if ($isAvailable) checked @endif />
</div>
