<div>
    <span class="badge bg-danger rounded-pill">{{ $count }}</span>
</div>
