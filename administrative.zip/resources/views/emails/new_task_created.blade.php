A new task {{ $task->name() }} has just been created.<br>
Click here to join: <a href="{{route('task.index')}}">{{ $task->name() }}</a>