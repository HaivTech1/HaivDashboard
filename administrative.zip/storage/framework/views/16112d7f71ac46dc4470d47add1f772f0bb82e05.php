<div>
    <span class="badge bg-danger rounded-pill"><?php echo e($count); ?></span>
</div>
<?php /**PATH C:\laragon\www\administrative\resources\views/livewire/components/nav/count.blade.php ENDPATH**/ ?>