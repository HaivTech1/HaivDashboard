<script src="<?php echo e(asset('libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/node-waves/waves.min.js')); ?>"></script>

<script src="<?php echo e(asset('libs/jquery.easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jquery-countdown/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/owl.carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/pages/ico-landing.init.js')); ?>"></script>

<script src="<?php echo e(asset('libs/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/spectrum-colorpicker2/spectrum.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap-timepicker/js/bootstrap-timepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/%40chenfengyuan/datepicker/datepicker.min.js')); ?>"></script>

<!-- plugin js -->
<script src="<?php echo e(asset('libs/moment/min/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jquery-ui-dist/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/%40fullcalendar/core/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/%40fullcalendar/bootstrap/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/%40fullcalendar/daygrid/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/%40fullcalendar/timegrid/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/%40fullcalendar/interaction/main.min.js')); ?>"></script>

<!-- Calendar init -->


<script src="<?php echo e(asset('libs/dropzone/min/dropzone.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('libs/jquery.repeater/jquery.repeater.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/pages/task-create.init.js')); ?>"></script>


<script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/notiflix.js')); ?>"></script>

<script src="<?php echo e(asset('js/functions.js')); ?>"></script>



<script>
$(document).ready(function() {
    toastr.options = {
        "positionClass": "toast-top-right",
        "progressBar": true
    }


    window.addEventListener('success', event => {
        toastr.success(event.detail.message, 'Success!');
    });

    window.addEventListener('error', event => {
        toastr.error(event.detail.message, 'Failed!');
    });

    window.addEventListener('info', event => {
        toastr.info(event.detail.message, 'Info!');
    });
})
</script>

<script>
    <?php if(Session::has('messege')): ?>
    var type = "<?php echo e(Session::get('alert-type','success')); ?>"
    switch (type) {
        case 'info':
            Notiflix.Report.Info("<?php echo e(Session::get('title')); ?>", "<?php echo e(Session::get('messege')); ?>",
                "<?php echo e(Session::get('button')); ?>", );
            break;
        case 'success':
            Notiflix.Report.Success("<?php echo e(Session::get('title')); ?>", "<?php echo e(Session::get('messege')); ?>",
                "<?php echo e(Session::get('button')); ?>", );
            break;
        case 'warning':
            Notiflix.Report.Warning("<?php echo e(Session::get('title')); ?>", "<?php echo e(Session::get('messege')); ?>",
                "<?php echo e(Session::get('button')); ?>", );
            break;
        case 'error':
            Notiflix.Report.Failure("<?php echo e(Session::get('title')); ?>", "<?php echo e(Session::get('messege')); ?>",
                "<?php echo e(Session::get('button')); ?>", );
            break;
    }
    <?php endif; ?>
</script>

<?php echo $__env->yieldContent('scripts'); ?>
<?php echo $__env->yieldPushContent('modals'); ?>
<script src="<?php echo e(asset('js/alpine.js')); ?>" defer></script>
<?php /**PATH C:\laragon\www\administrative\resources\views/partials/script.blade.php ENDPATH**/ ?>