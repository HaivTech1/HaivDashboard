<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-body">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.search','data' => []]); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </div>
                
                <table class="table align-middle table-nowrap table-check">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 20px;" class="align-middle">
                                <div class="form-check font-size-16">
                                    <input class="form-check-input" type="checkbox" id="checkAll"
                                        wire:model="selectPageRows">
                                    <label class="form-check-label" for="checkAll"></label>
                                </div>
                            </th>
                            <th class="align-middle">Name</th>
                            <th class="align-middle">Status</th>
                            <th class="align-middle">Members</th>
                            <th class="align-middle">Team</th>
                            <th class="align-middle">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="form-check font-size-16">
                                    <input class="form-check-input" value="<?php echo e($team->id); ?>" type="checkbox"
                                        id="<?php echo e($team->id); ?>" wire:model="selectedRows">
                                    <label class="form-check-label" for="<?php echo e($team->id); ?>"></label>
                                </div>
                            </td>
                            <td>
                                <?php echo e($team->name); ?>

                            </td>
                            <td>
                                <?php if(auth()->user()->isOwnerOfTeam($team)): ?>
                                <span class="badge badge-pill badge-soft-success font-size-12">Owner</span>
                                <?php else: ?>
                                <span class="badge badge-pill badge-soft-danger font-size-12">Member</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('teams.members.show', $team)); ?>" class="btn btn-sm btn-default">
                                    <i class="fa fa-users"></i> Members
                                </a>
                            </td>
                            <td>
                                <?php if(is_null(auth()->user()->currentTeam) ||
                                    auth()->user()->currentTeam->getKey() !== $team->getKey()): ?>
                                    <button wire:click="switchTeam(<?php echo e($team); ?>)" class="btn btn-sm btn-default">
                                        <i class="fa fa-sign-in"></i> Switch
                                    </button>
                                <?php else: ?>
                                    <span class="label label-default">Current team</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(auth()->user()->isOwnerOfTeam($team)): ?>
                                    <a href="<?php echo e(route('teams.edit', $team)); ?>" class="btn btn-sm btn-default">
                                        <i class="fa fa-pencil"></i> Edit
                                    </a>
                    
                                   
                                    <button wire:click='deleteTeam(<?php echo e($team); ?>)' class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i>
                                            Delete</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
    <div class='col-sm-4'>
        <form wire:submit.prevent="createTeam">
            <div class="hstack gap-3">
                <input class="form-control me-auto" wire:model.defer="name" placeholder="Add your team here..."
                    aria-label="Add your team here...">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.error','data' => ['for' => 'name']]); ?>
<?php $component->withName('form.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <button type="submit" class="btn btn-secondary">Add</button>
                <div class="vr"></div>
                <button wire:click="resetState" type="button" class="btn btn-outline-danger">Reset</button>
            </div>
        </form>

    </div>
</div><?php /**PATH C:\laragon\www\administrative\resources\views/livewire/manager/team/index.blade.php ENDPATH**/ ?>