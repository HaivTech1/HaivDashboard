<div>
    <input wire:model="isAvailable" type="checkbox" id="switch4" switch="success" / />
    <label for="switch4" data-on-label="Yes" data-off-label="No"></label>
</div><?php /**PATH C:\xampp\htdocs\HaivTech\resources\views/livewire/components/toggle-button.blade.php ENDPATH**/ ?>