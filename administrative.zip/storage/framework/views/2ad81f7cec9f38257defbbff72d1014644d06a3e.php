<div class="search-box me-2 mb-2 d-inline-block">
    <div class="position-relative">
        <input type="text" class="form-control" placeholder="Search..." wire:model="search">
        <i class="bx bx-search-alt search-icon"></i>
    </div>
</div><?php /**PATH C:\laragon\www\administrative\resources\views/components/search.blade.php ENDPATH**/ ?>