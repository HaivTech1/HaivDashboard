<!doctype html>
<html lang="en">


<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Colony')); ?></title>

    <?php echo $__env->make('partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <div class="home-btn d-none d-sm-block">
        <?php if(Route::has('login')): ?>
        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/dashboard')); ?>" class="text-dark">Dashboard</a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="text-dark mr-2">Log in</a>

            <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>" class="ml-4 p-2 text-dark">Register</a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <section class="my-5 pt-sm-5">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="home-wrapper">
                        <div class="mb-5">
                            <a href="index.html" class="d-block auth-logo">
                                <img src="<?php echo e(asset('storage/'.application('image'))); ?>" alt="" height="20"
                                    class="auth-logo-dark mx-auto">
                                <img src="assets/images/logo-light.png" alt="" height="20"
                                    class="auth-logo-light mx-auto">
                            </a>
                        </div>


                        <div class="row justify-content-center">
                            <div class="col-sm-4">
                                <div class="maintenance-img">
                                    <img src="/images/maintenance.svg" alt="" class="img-fluid mx-auto d-block">
                                </div>
                            </div>
                        </div>
                        <h3 class="mt-5"><?php echo e(application('name')); ?></h3>
                        <p><?php echo e(application('description')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <?php echo $__env->make('partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\HaivTech\resources\views/welcome.blade.php ENDPATH**/ ?>